# Guide AdMob — Activer les vraies publicités

## Étape 1 — Créer un compte AdMob

1. Aller sur https://admob.google.com
2. Se connecter avec votre compte Google
3. Cliquer "Commencer"
4. Remplir les informations (pays, devise: MAD pour Maroc)

---

## Étape 2 — Créer l'application dans AdMob

1. Dans AdMob → "Applications" → "Ajouter une application"
2. Plateforme : Android
3. L'app est-elle sur le Play Store ? → Non (pour commencer)
4. Nom de l'app : EduPresence
5. Copier votre **App ID** : ca-app-pub-XXXXXXXX~XXXXXXXXXX

---

## Étape 3 — Créer les blocs d'annonces

### Bannière (en bas de l'écran)
1. Applications → EduPresence → "Blocs d'annonces" → "Ajouter un bloc"
2. Type : Bannière
3. Nom : "Banniere_Bas"
4. Copier l'**Ad Unit ID** : ca-app-pub-XXXXXXXX/XXXXXXXXXX

### Interstitiel (plein écran)
1. Même chose → Type : Interstitiel
2. Nom : "Interstitiel_Pages"
3. Copier l'**Ad Unit ID**

---

## Étape 4 — Remplacer les IDs dans le code

Ouvrir `android/app/build.gradle` :
```
admobAppId: "ca-app-pub-VOTRE-APP-ID"
```

Ouvrir `android/app/src/main/java/.../MainActivity.java` :
```java
private static final String BANNER_AD_UNIT_ID  = "ca-app-pub-VOTRE-BANNER-ID";
private static final String INTERSTITIAL_AD_ID = "ca-app-pub-VOTRE-INTER-ID";
```

---

## Étape 5 — Recompiler et publier

1. Android Studio → Build → Generate Signed APK
2. Tester sur votre téléphone
3. Vérifier que les pubs s'affichent
4. Publier sur le Play Store

---

## 💰 Revenus estimés (Maroc)

| Utilisateurs actifs | Revenus/mois estimés |
|---|---|
| 100 | 3 - 8 $ |
| 500 | 15 - 40 $ |
| 1 000 | 30 - 80 $ |
| 5 000 | 150 - 400 $ |
| 10 000 | 300 - 800 $ |

**CPM Maroc** (pour 1000 affichages) : 0.5 $ à 2 $
**RPM moyen enseignants** : environ 1.5 $/1000 sessions

---

## ⚙️ Configuration des pubs dans l'app

La bannière s'affiche en bas de l'écran en permanence.
L'interstitiel (plein écran) apparaît toutes les 5 changements de page.

Pour modifier la fréquence, changer dans MainActivity.java :
```java
if (pageCount % 5 == 0)  // ← changer 5 par le nombre voulu
```

---

## ✅ Pubs actuellement configurées (TEST)

Les IDs actuels sont des IDs de TEST Google.
Ils affichent de fausses publicités pendant le développement.
Remplacez-les par vos vrais IDs avant de publier.
