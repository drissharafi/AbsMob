# EduPresence — Guide Complet APK & Play Store

## 📁 Structure du projet
```
edupresence-playstore/
├── android/
│   ├── app/
│   │   ├── src/main/
│   │   │   ├── assets/
│   │   │   │   └── index.html          ← L'application complète
│   │   │   ├── java/com/edupresence/app/
│   │   │   │   └── MainActivity.java   ← Code Android natif
│   │   │   ├── res/
│   │   │   │   ├── values/strings.xml  ← Nom de l'app
│   │   │   │   ├── values/styles.xml   ← Thème bleu
│   │   │   │   └── xml/network_security_config.xml
│   │   │   └── AndroidManifest.xml     ← Configuration Android
│   │   ├── build.gradle                ← Config de compilation
│   │   └── proguard-rules.pro
│   ├── build.gradle
│   └── settings.gradle
└── fastlane/
    └── metadata/android/fr-FR/
        └── full_description.txt        ← Description Play Store
```

---

## 🔨 MÉTHODE 1 — Compiler l'APK (avec Android Studio)

### Étape 1 — Installer Android Studio
1. Télécharger : https://developer.android.com/studio
2. Installer Android Studio (gratuit)
3. Au premier lancement → installer Android SDK automatiquement

### Étape 2 — Ouvrir le projet
1. Ouvrir Android Studio
2. **"Open an Existing Project"**
3. Sélectionner le dossier **`android/`**
4. Attendre la synchronisation Gradle (2-5 minutes)

### Étape 3 — Ajouter les icônes
Remplacer les fichiers dans `res/mipmap-*/` par votre icône :
- mipmap-mdpi     → ic_launcher.png (48×48 px)
- mipmap-hdpi     → ic_launcher.png (72×72 px)
- mipmap-xhdpi    → ic_launcher.png (96×96 px)
- mipmap-xxhdpi   → ic_launcher.png (144×144 px)
- mipmap-xxxhdpi  → ic_launcher.png (192×192 px)
Outil gratuit : https://icon.kitchen

### Étape 4 — Générer l'APK
1. Menu **Build** → **Generate Signed Bundle / APK**
2. Choisir **APK**
3. Créer un **Keystore** (première fois) :
   - Key store path : choisir un dossier sûr
   - Password : choisir un mot de passe fort
   - Alias : `edupresence`
   - Validity : 25 ans
4. Choisir **release**
5. Cliquer **Finish**
6. L'APK est dans : `app/release/app-release.apk`

### Étape 5 — Installer l'APK sur Android
1. Copier `app-release.apk` sur votre téléphone
2. Paramètres → Sécurité → **Sources inconnues** → Activer
3. Ouvrir le fichier APK → **Installer**
4. L'app apparaît sur l'écran d'accueil ✅

---

## 🏪 MÉTHODE 2 — Publier sur le Play Store

### Prérequis
- Compte Google Play Developer : https://play.google.com/console
- Frais unique : **25 USD**
- Un AAB (Android App Bundle) au lieu de l'APK

### Étape 1 — Générer le AAB
1. Dans Android Studio → **Build** → **Generate Signed Bundle / APK**
2. Choisir **Android App Bundle**
3. Utiliser le même Keystore créé précédemment
4. Le fichier AAB est dans : `app/release/app-release.aab`

### Étape 2 — Créer l'app sur Play Console
1. Aller sur https://play.google.com/console
2. **"Créer une application"**
3. Nom : **EduPresence**
4. Langue : Français
5. Type : Application
6. Gratuite

### Étape 3 — Remplir les informations
- Description courte : "Gestion des absences des élèves pour enseignants"
- Description complète : voir `fastlane/metadata/android/fr-FR/full_description.txt`
- Catégorie : **Éducation**
- Captures d'écran : minimum 2 screenshots (prendre sur votre téléphone)
- Icône haute résolution : 512×512 px
- Bannière : 1024×500 px

### Étape 4 — Soumettre
1. Aller dans **Production** → **Créer une version**
2. Uploader le fichier `.aab`
3. Ajouter les notes de version : "Version initiale"
4. **Soumettre pour révision**
5. Attendre 1 à 3 jours pour validation Google

---

## ⚡ MÉTHODE 3 — APK rapide sans Android Studio (PWABuilder)

1. Aller sur https://pwabuilder.com
2. Entrer l'URL : `resonant-sunflower-50135d.netlify.app`
3. Cliquer **"Start"** → attendre l'analyse
4. **"Package for stores"** → **Android**
5. Télécharger le APK ou AAB
6. Installer directement ou soumettre au Play Store

---

## 🔧 Modifier l'app

Pour modifier l'application :
1. Ouvrir `android/app/src/main/assets/index.html`
2. Modifier le code HTML/CSS/JavaScript
3. Recompiler l'APK dans Android Studio
4. Réinstaller ou soumettre une nouvelle version

---

## 📞 Informations techniques

| Paramètre | Valeur |
|---|---|
| Package ID | com.edupresence.app |
| Version | 3.0 (code: 3) |
| SDK minimum | Android 5.0 (API 21) |
| SDK cible | Android 14 (API 34) |
| Architecture | WebView (HTML/JS) |
| Taille APK estimée | ~2-3 Mo |
| Stockage données | localStorage (sur l'appareil) |
| Internet requis | Non (100% hors ligne) |

---

## ⚠️ Points importants

1. **Keystore** — Conservez précieusement votre fichier keystore et mot de passe.
   Si vous le perdez, vous ne pouvez plus mettre à jour l'app sur le Play Store.

2. **Données utilisateurs** — Les données sont dans le localStorage du WebView.
   Elles persistent entre les mises à jour de l'app.

3. **Mises à jour** — Pour mettre à jour l'app :
   - Modifier `index.html`
   - Incrémenter `versionCode` dans `build.gradle`
   - Recompiler et soumettre le nouveau AAB

---
EduPresence v3.0 — Développé pour les enseignants
