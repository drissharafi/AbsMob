#!/usr/bin/env python3
"""
Génère les icônes EduPresence pour toutes les densités Android.
Usage: python3 generate_icons.py
Requis: pip install Pillow
"""

try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError:
    print("Installation de Pillow...")
    import subprocess
    subprocess.run(["pip", "install", "Pillow", "--break-system-packages"])
    from PIL import Image, ImageDraw, ImageFont

import os

SIZES = {
    "mipmap-mdpi":    48,
    "mipmap-hdpi":    72,
    "mipmap-xhdpi":   96,
    "mipmap-xxhdpi":  144,
    "mipmap-xxxhdpi": 192,
}

def generate_icon(size, output_path):
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    
    # Fond bleu avec coins arrondis
    radius = size // 5
    draw.rounded_rectangle([(0, 0), (size-1, size-1)], radius=radius, fill=(21, 101, 192, 255))
    
    # Cercle blanc en haut
    margin = size // 6
    circle_r = size // 4
    cx, cy = size // 2, size // 3
    draw.ellipse([cx-circle_r, cy-circle_r, cx+circle_r, cy+circle_r], fill=(255, 255, 255, 255))
    
    # Corps (rectangle blanc arrondi)
    bw = size // 2
    bh = size // 4
    bx = size // 2 - bw // 2
    by = size * 2 // 3 - bh // 2
    draw.rounded_rectangle([bx, by, bx+bw, by+bh], radius=size//12, fill=(255, 255, 255, 230))
    
    # Lignes représentant une liste
    line_y = by + bh // 3
    lm = bx + size // 16
    for i in range(2):
        y = line_y + i * (bh // 3)
        draw.rectangle([lm, y, lm + bw * 3 // 5, y + size // 40], fill=(21, 101, 192, 200))
    
    img.save(output_path, "PNG")
    print(f"  ✅ {output_path} ({size}×{size})")

base = "android/app/src/main/res"
print("🎨 Génération des icônes EduPresence...\n")

for folder, size in SIZES.items():
    path = os.path.join(base, folder)
    os.makedirs(path, exist_ok=True)
    generate_icon(size, os.path.join(path, "ic_launcher.png"))
    generate_icon(size, os.path.join(path, "ic_launcher_round.png"))

# Icône Play Store haute résolution (512×512)
generate_icon(512, "ic_launcher_playstore.png")

print("\n✅ Toutes les icônes générées !")
print("   Icône Play Store : ic_launcher_playstore.png (512×512)")
