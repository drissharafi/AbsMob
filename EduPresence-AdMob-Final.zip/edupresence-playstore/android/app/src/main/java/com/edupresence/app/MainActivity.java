package com.edupresence.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.WebChromeClient;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.view.Window;
import android.view.WindowManager;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.FrameLayout;
import android.os.Build;
import android.util.Log;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

public class MainActivity extends Activity {

    private static final String TAG = "EduPresence";

    // ⚠️ REMPLACER par vos vrais IDs après inscription sur admob.google.com
    // IDs de TEST ci-dessous (fausses pubs pendant développement)
    private static final String BANNER_AD_UNIT_ID  = "ca-app-pub-3940256099942544/6300978111";
    private static final String INTERSTITIAL_AD_ID = "ca-app-pub-3940256099942544/1033173712";

    private WebView webView;
    private AdView bannerAdView;
    private InterstitialAd interstitialAd;
    private int pageCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(0xFF0D47A1);
        }

        // Layout : WebView + Bannière en bas
        LinearLayout rootLayout = new LinearLayout(this);
        rootLayout.setOrientation(LinearLayout.VERTICAL);

        webView = new WebView(this);
        LinearLayout.LayoutParams webParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1.0f);
        rootLayout.addView(webView, webParams);

        FrameLayout bannerContainer = new FrameLayout(this);
        LinearLayout.LayoutParams bannerParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT);
        rootLayout.addView(bannerContainer, bannerParams);

        setContentView(rootLayout);

        // WebView settings
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(false);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);

        CookieManager.getInstance().setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        }

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url); return true;
            }
            @Override
            public void onPageFinished(WebView view, String url) {
                view.evaluateJavascript("if(typeof onAndroidReady==='function') onAndroidReady();", null);
            }
        });

        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AdMobBridge(), "AdMob");
        webView.loadUrl("file:///android_asset/index.html");

        // Init AdMob
        MobileAds.initialize(this, status -> {
            Log.d(TAG, "AdMob OK");
            loadBannerAd(bannerContainer);
            loadInterstitialAd();
        });
    }

    private void loadBannerAd(FrameLayout container) {
        bannerAdView = new AdView(this);
        bannerAdView.setAdUnitId(BANNER_AD_UNIT_ID);
        bannerAdView.setAdSize(AdSize.BANNER);
        bannerAdView.setAdListener(new AdListener() {
            @Override public void onAdLoaded() { container.setVisibility(View.VISIBLE); }
            @Override public void onAdFailedToLoad(LoadAdError e) { container.setVisibility(View.GONE); }
        });
        container.addView(bannerAdView);
        bannerAdView.loadAd(new AdRequest.Builder().build());
    }

    private void loadInterstitialAd() {
        InterstitialAd.load(this, INTERSTITIAL_AD_ID, new AdRequest.Builder().build(),
            new InterstitialAdLoadCallback() {
                @Override public void onAdLoaded(InterstitialAd ad) {
                    interstitialAd = ad;
                    interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                        @Override public void onAdDismissedFullScreenContent() {
                            interstitialAd = null; loadInterstitialAd();
                        }
                        @Override public void onAdFailedToShowFullScreenContent(AdError e) {
                            interstitialAd = null; loadInterstitialAd();
                        }
                    });
                }
                @Override public void onAdFailedToLoad(LoadAdError e) { interstitialAd = null; }
            });
    }

    private void showInterstitialAd() {
        if (interstitialAd != null) interstitialAd.show(this);
    }

    // Bridge JavaScript <-> Java
    public class AdMobBridge {

        // Appeler depuis JS quand l'utilisateur change de page
        @JavascriptInterface
        public void onPageChanged() {
            pageCount++;
            if (pageCount % 5 == 0) {
                runOnUiThread(() -> showInterstitialAd());
            }
        }

        // Afficher pub plein écran manuellement
        @JavascriptInterface
        public void showInterstitial() {
            runOnUiThread(() -> showInterstitialAd());
        }

        // Cacher bannière (version premium)
        @JavascriptInterface
        public void hideBanner() {
            runOnUiThread(() -> {
                if (bannerAdView != null) bannerAdView.setVisibility(View.GONE);
            });
        }

        @JavascriptInterface
        public boolean isAvailable() { return true; }
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onPause() {
        super.onPause(); webView.onPause();
        if (bannerAdView != null) bannerAdView.pause();
    }

    @Override protected void onResume() {
        super.onResume(); webView.onResume();
        if (bannerAdView != null) bannerAdView.resume();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (bannerAdView != null) bannerAdView.destroy();
        webView.destroy();
    }
}
